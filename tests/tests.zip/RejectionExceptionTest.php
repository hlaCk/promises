<?php

namespace hlaCk\Promise\Tests;

use hlaCk\Promise\RejectionException;
use PHPUnit\Framework\TestCase;

/**
 * @covers hlaCk\Promise\RejectionException
 */
class RejectionExceptionTest extends TestCase
{
    public function testCanGetReasonFromException()
    {
        $thing = new Thing1('foo');
        $e = new RejectionException($thing);

        $this->assertSame($thing, $e->getReason());
        $this->assertSame('The promise was rejected with reason: foo', $e->getMessage());
    }

    public function testCanGetReasonMessageFromJson()
    {
        $reason = new Thing2();
        $e = new RejectionException($reason);
        $this->assertStringContainsString("{}", $e->getMessage());
    }
}
